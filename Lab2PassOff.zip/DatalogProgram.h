#pragma once

/*The order must be: Schemes, then Facts, then Rules, then Queries

 There must be at least one Scheme and at least one Query
        There does not have to be any Facts or Rules

        datalogProgram  ->  SCHEMES COLON scheme schemeList
                            FACTS   COLON        factList
                            RULES   COLON        ruleList
                            QUERIES COLON query  queryList*/

class DatalogProgram {

private:
    vector<Predicate> schemesList;
    vector<Predicate> factsList;
    vector<Rule> rulesList;
    vector<Predicate> queriesList;


public:
    DatalogProgram() {}
    ~DatalogProgram() {}

    void addPredicate() {

    }

    string toString() {
        return "";
    }

};