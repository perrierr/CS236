#pragma once
#include "Header.h"
#include "Tuple.h"
#include <iostream>
#include <cstring>
#include <set>


class Relation {
private:
    string name = "";
    string tupleValue = "";
    Header header;
    set<Tuple> tuples;
    vector<string> values;
    vector<int> indices;

public:

    void SetName(string theName) {
        name = theName;
    }

    void SetHeader(vector <Parameter*> params) {

        for (auto & param : params) {
            header.AddAttributes(param->GetName());
        }
    }

    void DeleteHeaderAttributes(int index) {

        header.DeleteAttributes(index);

    }

    string GetHeader(int index) {
        vector <string> name = header.GetAttributes();
        string myString;
        myString = name.at(index);
        return myString;
    }

    char GetHeaderCharacter(int index) {
        vector <string> name = header.GetAttributes();
        string myString;
        myString = name.at(index);
        char finalString = myString.at(0);
        return finalString;
    }

    unsigned int GetHeaderSize() {
        return header.GetAttributesSize();
    }

    void SetTuples(vector <Parameter*> params) {

        Tuple tuple;

        for (unsigned int i = 0; i < params.size(); i++) {
            tupleValue = params.at(i)->GetName();
            tuple.Add(params.at(i)->GetName());
        }
        tuples.insert(tuple);

        //cout << "size " << tuples.size();
    }

    void SetTuples(vector<string> newColumns) {
        Tuple tuple;

        for (unsigned int i = 0; i < newColumns.size(); i++) {
            tupleValue = newColumns.at(i);
            tuple.Add(newColumns.at(i));
        }
        tuples.insert(tuple);
    }

    void SetTuples(Tuple tuple) {
        tuples.insert(tuple);
        //cout << "size " << tuples.size();
    }

    void DeleteTuples(Tuple tuple) {

        auto it = tuples.find(tuple);
        tuples.erase(it);

    }

    string GetName() {
        return name;
    }

    set<Tuple> GetTuples() {
        return tuples;
    }

    void PrintTuplesAtPosition(int index) {
        //cout << tuples.at(index);
    }

    void SetValuesVector(string name) {
        values.push_back(name);
    }

    void SetIndicesVector(int index) {
        indices.push_back(index);
    }

    vector<string> GetValuesVector() {
        return values;
    }

    string GetValuesVectorPosition(int index) {
        return values.at(index);
    }

    vector<int> GetIndicesVector() {
        return indices;
    }

    void PrintRelation() {
        vector <string> myAttributes = header.GetAttributes();
        for (unsigned int i = 0; i <  myAttributes.size(); i++) {
            cout << myAttributes.at(i);
        }
        cout << endl;
        for (Tuple e : tuples) {
            e.toString();
        }
    }

    Relation* CreateQueries(Relation *newRelation) {

        string valueConstant = "";
        unsigned int indexConstant = 0;
        unsigned int indexVariableOne = 0;
        unsigned int indexVariableTwo = 0;

        for (unsigned int i = 0; i < newRelation->GetHeaderSize(); i++) {
            if (newRelation->GetHeaderCharacter(i) == '\'') {
                valueConstant = newRelation->GetHeader(i);
                indexConstant = i;
                newRelation = Select1(valueConstant, indexConstant, newRelation);
            }
            if (newRelation->GetHeaderCharacter(i) != '\'') {
                if (indexVariableOne < newRelation->GetHeaderSize()) {
                    indexVariableOne = i;
                    indexVariableTwo = i+1;
                    newRelation = Select2(indexVariableOne, indexVariableTwo, newRelation);
                }
            }

            if(newRelation->GetHeaderSize() - 1 == i) {
                newRelation = Select3(newRelation);
            }
        }

/*        cout << endl;

        cout << "print my values " << endl;
        for (unsigned int i = 0; i < values.size(); i++) {
            cout << values.at(i);
        }

        cout << endl;

        cout << "after: " << endl;
        for (auto itr: newRelation->GetTuples()) {
            (itr).toString();
        }*/

        //TODO MAKE SURE TO TREAT RELATIION WITH EMPTY TUPLES
/*        if (newRelation->GetTuples().empty()) {
            cout << "NO" << endl;
        }*/

/*        for (auto itr: newRelation->GetTuples()) {
            for (unsigned int i = 0; i < GetHeaderSize(); i++) {
                if (newRelation->GetHeaderCharacter(i) != '\'') {
                    newRelation = Project(newRelation);
                    cout << "after: " << endl;
                    for (auto itr: newRelation->GetTuples()) {
                        (itr).toString();
                    }
                    break;
                } else {
                    cout << "NoPROJECT: " << endl;
                    for (auto itr: newRelation->GetTuples()) {
                        (itr).toString();
                    }
                    break;
                }
            }
            break;
        }*/

        return newRelation;

    }

    void PrintNewRelation(Relation *newRelation) {


        if (newRelation->GetTuples().empty()) {
            cout << newRelation->GetName();
            header.PrintAttributes();
            cout << " No" << endl;
        } else {
            cout << newRelation->GetName();
            header.PrintAttributes();
            cout << " Yes(" << newRelation->GetTuples().size() << ")" << endl;
            //TODO RENAME HEADER
            int index;
            for (unsigned int i = 0; i < newRelation->GetHeaderSize(); i++) {
                if (newRelation->GetHeaderCharacter(i) == '\'') {
                    index = i;
                    newRelation = newRelation->Rename(index, newRelation);
                }
            }

        }

/*        for (unsigned int i = 0; i < newRelation->GetValuesVector().size(); i++) {
            cout << newRelation->GetValuesVector().at(i);
        }

        for (unsigned int i = 0; i < newRelation->GetIndicesVector().size(); i++) {
            cout << newRelation->GetIndicesVector().at(i);
        }*/

        for (unsigned int i = 0; i < newRelation->GetValuesVector().size(); i++) {
            if (newRelation->GetHeaderCharacter(i) != '\'') {
                Tuple newTuple;
                set<Tuple>::iterator tupleItr;
                tupleItr = tuples.begin();
                while (tupleItr != tuples.end()) {
                    cout << "  ";
                    if (!newRelation->GetTuples().empty()) {
                        for (unsigned int i = 0; i < newRelation->GetValuesVector().size(); i++) {
                            if (i == newRelation->GetIndicesVector().size() - 1) {
                                cout << newRelation->GetValuesVector().at(i);
                                //header.PrintAttributesAtPosition(newRelation->GetIndicesVector().at(i));
                                cout << "=";
                                newTuple = *tupleItr;
                                newTuple.PrintTupleAtPosition(i);
                                break;
                            } else {
                                cout << newRelation->GetValuesVector().at(i);
                                //header.PrintAttributesAtPosition(newRelation->GetIndicesVector().at(i));
                                cout << "=";
                                newTuple = *tupleItr;
                                newTuple.PrintTupleAtPosition(i);
                            }
                            cout << ", ";
                        }
                    }
                    cout << endl;
                    tupleItr++;
                }

            }
            break;
        }

    }

    //TODO FUNCTION select: parameters are index and value (relation column and value to select)
    Relation* Select1(string valueConstant, unsigned int indexConstant, Relation* &relation) {
        //cout << "valueConstant " << valueConstant << endl;
        //cout << "indexConstant " << indexConstant << endl;

/*        cout << "before: " << endl;
        for (auto itr: relation->GetTuples()) {
            (itr).toString();
        }*/
        Tuple newTuple;
        set<Tuple>::iterator tupleItr;
        tupleItr = tuples.begin();
        while(tupleItr != tuples.end())
        {
            newTuple = *tupleItr;
            if(!newTuple.FoundValue(valueConstant, indexConstant)) {
                tupleItr = tuples.erase(tupleItr);
            } else {
                tupleItr++;
            }
        }

        return relation;
    }

    //TODO FUNCTION project: parameter is list of indices (the columns to keep) - IT WILL KEEP ONLY CERTAIN COLUMN OF YOUR TUPLE
    Relation* Select2(int indexVariableOne, int indexVariableTwo, Relation *&relation) {

        // if vector is empty push the header into vector
        // else look up if you have seen this variable
        // if you have DO a select
        // else mark it
        string value = relation->GetHeader(indexVariableOne);
        if (values.empty()) {
            relation->SetValuesVector(value);
            relation->SetIndicesVector(indexVariableOne);
        } else {
            unsigned int i = 0;
            bool valueFound = false;
            while (i < relation->GetValuesVector().size()) {
                if(relation->GetValuesVector().at(i) != relation->GetHeader(indexVariableOne)) {
                    i++;
                } else {
                        valueFound = true;
                        Tuple newTuple;
                        set<Tuple>::iterator tupleItr;
                        tupleItr = tuples.begin();
                        while(tupleItr != tuples.end())
                        {
                            newTuple = *tupleItr;
                            if(!newTuple.FoundValue(i, indexVariableOne)) {
                                tupleItr = tuples.erase(tupleItr);
                            } else {
                                //This crashes during debug
                                tupleItr++;
                            }
                        }
                        valueFound = true;
                        i++;
                }
            }

            if(!valueFound) {
                relation->SetValuesVector(value);
                relation->SetIndicesVector(indexVariableOne);
            }

        }
        return relation;
    }



    Relation* Select3(Relation* &relation) {

        if(values.empty()) {
            return relation;
        } else {
            set<Tuple> temporaryTuples = relation->GetTuples();

            for(Tuple e : relation->GetTuples()) {
                relation->DeleteTuples(e);
            }

            Tuple newTuple;
            for (Tuple e : temporaryTuples) {
                vector <string> newTuples = e.FoundValue(indices);
                relation->SetTuples(newTuples);
            }
        }
        return relation;
    }



    //TODO FUNCTION project: parameter is list of indices (the columns to keep) - IT WILL KEEP ONLY CERTAIN COLUMN OF YOUR TUPLE
    Relation* Project(Relation *relation) {

        return relation;

    }

    //TODO FUNCTION rename: parameter is list of attributes (defines the new header)
    //RENAME WILL CHANGE THE HEADER OF THE RELATION

    Relation* Rename(int index, Relation *relation) {

        relation->DeleteHeaderAttributes(index);

        return relation;
    }

};