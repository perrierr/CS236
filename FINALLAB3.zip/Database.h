#pragma once
#include "Relation.h"
#include <map>


class Database {
private:

public:
    map<string, Relation*> tables;

    void CreateMapKeyHeader(vector <Predicate*> schemesList) {
        for (auto & i : schemesList) {
            auto* relation = new Relation;
            relation->SetName(i->GetName());
            relation->SetHeader(i->GetParameters());
            //relation->PrintHeader();
            //relation->PrintName();
            tables.insert(std::pair<string, Relation*>(relation->GetName(),relation));
        }
/*        cout << "myMap contains:\n";
        for (itr = tables.begin(); itr!= tables.end(); itr++) {
            cout << "Key" << itr->first << endl;
            cout << "relation ";
            itr->second->PrintRelation();
        }*/
    }

    void AddTuples (vector<Predicate*> factsList) {
        for (unsigned int i = 0; i < factsList.size(); i++) {
            auto itr = tables.find(factsList.at(i)->GetName());
            itr->second->SetTuples(factsList.at(i)->GetParameters());
        }

/*        cout << "myMap contains:\n";
        for (auto itr = tables.begin(); itr != tables.end(); itr++) {
            cout << "Key: " << itr->first << endl;
            cout << "Relation: ";
            itr->second->PrintRelation();
        }*/
    }

    void CreateQueries(vector<Predicate*> queriesList) {

        for(auto & i : queriesList) {
            auto *newRelation = new Relation();
            newRelation->SetName(i->GetName());
            newRelation->SetHeader(i->GetParameters());

            // find the table for the given name
            auto itr = tables.find(i->GetName());

            //cout << "Found Tuples:" << endl;
            // get tuple for the found table
            set<Tuple> foundTuples = itr->second->GetTuples();
            set<Tuple>::iterator tupleItr;
            for (tupleItr = foundTuples.begin(); tupleItr != foundTuples.end(); tupleItr++) {
                Tuple foundTuple = *tupleItr;

                //foundTuple.toString();
                newRelation->SetTuples(foundTuple);
            }

            newRelation = newRelation->CreateQueries(newRelation);
            newRelation->PrintNewRelation(newRelation);
        }
    }

};
